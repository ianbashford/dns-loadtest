package main

import (
	"bufio"
	"context"
	"fmt"
	"log"
	"net"
	"os"
	"time"
)

func CreateResolver() *net.Resolver {
	r := &net.Resolver{
		PreferGo: true,
		Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
			d := net.Dialer{
				Timeout: time.Millisecond * time.Duration(5000),
			}
			return d.DialContext(ctx, network, "192.168.3.10:5353")
		},
	}
	return r
}

func ResolveName(r *net.Resolver, hostname string) (bool, string) {
	addr, err := r.LookupHost(context.Background(), hostname)
	if err != nil || len(addr) == 0 {
		addr, err := r.LookupHost(context.Background(), "www."+hostname)
		if err != nil {
			fmt.Println(err)
			return false, ""
		} else if len(addr) == 0 {
			fmt.Printf("%s or %s - no results", hostname, "www."+hostname)
			return false, ""
		} else {
			return true, "www." + hostname
		}
	}
	return true, hostname

}

func RunProg(inputFilename string, outputFileName string) {

	outputFile, err := os.Create(outputFileName)
	if err != nil {
		log.Fatalf("failed creating file: %s", err)
	}
	defer func() {
		if err := outputFile.Close(); err != nil {
			panic(err)
		}
	}()

	//
	inputFile, err := os.Open(inputFilename)
	if err != nil {
		log.Fatal(err)
	}
	defer func() {
		if err := inputFile.Close(); err != nil {
			panic(err)
		}
	}()

	r := CreateResolver()

	scanner := bufio.NewScanner(inputFile)
	for scanner.Scan() {
		result, name := ResolveName(r, scanner.Text())
		if result {
			outputFile.Write([]byte(name))
			outputFile.WriteString("\n")
		}
	}

	if err := scanner.Err(); err != nil {
		log.Fatal(err)
	}

	if err != nil {
		log.Fatalf("failed writing to file: %s", err)
	}

}

func main() {
	inputFileName := "/home/ian/development/dns-loadtest/testdata/QC-Clean.txt"
	outputFileName := "/tmp/test.txt"
	RunProg(inputFileName, outputFileName)

}
